package ajedrezinterfaz;

import javax.swing.*;


public class Casilla extends JButton{
    public Pieza p = null;
    public int x;
    public int y;

    Casilla (int x, int y){
        this.x = x;
        this.y = y;
        p = new Pieza();
    }
}
