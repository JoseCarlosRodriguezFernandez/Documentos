package ajedrezinterfaz;

public class Pieza {
    String tipo;
    String color;

    Pieza() {

    }
}
