package ajedrezinterfaz;


public class Tablero {
    public int numFil = 8;
    public int numCol = 8;
    public Casilla [][] t = new Casilla [numFil][numCol];
    
    Tablero(){
        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t.length; j++) {
                t[i][j]=new Casilla(i,j);
                t[i][j].setText(i+","+j);
            }
            
        }
        
    }
}


