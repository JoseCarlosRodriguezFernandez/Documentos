package ajedrezinterfaz;

import java.awt.*;
import javax.swing.*;

public class Pieza {
    String tipo;
    String color;
    ImageIcon imagen;
    

    Pieza(String tipo, String color, String ruta) {
        this.tipo = tipo;
        this.color = color;
        this.imagen = new ImageIcon(getClass().getResource(ruta));
    }
    
    public void reescalarImagen(JButton boton){
        Image img = imagen.getImage();
        Image otraimg = img.getScaledInstance(55,55,java.awt.Image.SCALE_SMOOTH);
        ImageIcon otroicon = new ImageIcon(otraimg);
        boton.setIcon(otroicon);
    }
}
