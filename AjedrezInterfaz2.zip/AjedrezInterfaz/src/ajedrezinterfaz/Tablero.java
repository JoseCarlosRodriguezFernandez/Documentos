package ajedrezinterfaz;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Tablero {
    public int numFil = 8;
    public int numCol = 8;
    public Casilla [][] t = new Casilla [numFil][numCol];
    
    Tablero(){
        
        ActionListener listener = new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                if( ((Casilla)e.getSource()).p != null){
                    System.out.println("Pieza");
                }else{
                    System.out.println("Casilla vacía");
                }
            }
        };
        
        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t.length; j++) {
                t[i][j]=new Casilla(i,j);
                t[i][j].addActionListener(listener);
                
                if(i%2 != 0){
                    if(j%2 != 0){
                        t[i][j].setBackground(Color.red);
                    }else{
                        t[i][j].setBackground(Color.yellow);
                    }
                }
                if(i%2==0){
                    if(j%2 == 0){
                        t[i][j].setBackground(Color.red);
                    }else{
                        t[i][j].setBackground(Color.yellow);
                    }
                }

                
                
                if (i == 0){
                    if(j == 0 || j == 7){
                        t[i][j].p = new Pieza("Torre", "Negro","/img/TorreNegra.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 1 || j == 6){
                        t[i][j].p = new Pieza("Caballo", "Negro","/img/CaballoNegro.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 2 || j == 5){
                        t[i][j].p = new Pieza("Alfil", "Negro","/img/AlfilNegro.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 3){
                        t[i][j].p = new Pieza("Reina", "Negro","/img/ReinaNegra.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 4){
                        t[i][j].p = new Pieza("Rey", "Negro","/img/ReyNegro.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                }
                if (i == 1){
                    t[i][j].p = new Pieza("Peon", "Negro","/img/PeonNegro.png");
                    t[i][j].setIcon(t[i][j].p.imagen);
                    t[i][j].p.reescalarImagen(t[i][j]);
                }
                if (i == 6){
                    t[i][j].p = new Pieza("Peon", "Blanco","/img/PeonBlanco.png");
                    t[i][j].setIcon(t[i][j].p.imagen);
                    t[i][j].p.reescalarImagen(t[i][j]);
                }
                if (i == 7){
                    if(j == 0 || j == 7){
                        t[i][j].p = new Pieza("Torre", "Blanco","/img/TorreBlanca.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 1 || j == 6){
                        t[i][j].p = new Pieza("Caballo", "Blanco","/img/CaballoBlanco.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 2 || j == 5){
                        t[i][j].p = new Pieza("Alfil", "Blanco","/img/AlfilBlanco.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 3){
                        t[i][j].p = new Pieza("Reina", "Blanco","/img/ReinaBlanca.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 4){
                        t[i][j].p = new Pieza("Rey", "Blanco","/img/ReyBlanco.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                }
            }
        }
    }
}


