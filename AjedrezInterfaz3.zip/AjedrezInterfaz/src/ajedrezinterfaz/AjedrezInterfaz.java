package ajedrezinterfaz;

import java.awt.*;
import javax.swing.*;

public class AjedrezInterfaz extends JFrame{

    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Ajedrez");
        frame.setSize(640,640);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        JPanel panel = new JPanel();
        Tablero m = new Tablero();
        frame.add(panel);
        panel.setLayout(new GridLayout(m.numFil, m.numCol));
    
        for (int i = 0; i < m.numFil; i++) {
            for (int j = 0; j < m.numCol; j++) {
                panel.add(m.t[i][j]);
                
            }
        
        }
    
        frame.setVisible(true);
    
        }
    
}
