package ajedrezinterfaz;

import java.awt.Point;
import java.util.ArrayList;

public class Caballo extends Pieza{
 
    Caballo(String tipo, String color, String ruta){
        super(tipo, color, ruta);
    }

    @Override
    public ArrayList<Point> movValidos(int posX, int posY) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
