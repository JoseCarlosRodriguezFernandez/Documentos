package ajedrezinterfaz;

import java.awt.Point;
import java.util.ArrayList;

public class Peon extends Pieza{
    ArrayList<Point> c = new ArrayList();

    Peon(String tipo, String color, String ruta){
        super(tipo, color, ruta);
    }
    
    @Override
    public ArrayList <Point> movValidos(int posX, int posY){
        ArrayList <Point> movimientos = new ArrayList();
        Point mov1 = new Point(posX+1, posY+1);
        movimientos.add(mov1);
        
        System.out.println("Esto es un peon");
 
        
        return (movimientos);
        
    }
}
