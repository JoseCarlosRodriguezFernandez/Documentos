package ajedrezinterfaz;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Tablero {
    public int numFil = 8;
    public int numCol = 8;
    public Casilla [][] t = new Casilla [numFil][numCol];
    public static Casilla aux;
    
    
    Tablero(){
        
        ActionListener listener = new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                if( ((Casilla)e.getSource()).p != null){
                    if(aux == null){
                        piezapulsada((Casilla)e.getSource());
                    }else{
                        mover((Casilla)e.getSource());
                    }
                }else if (aux != null){
                    mover((Casilla)e.getSource());
                }
            }
        };
        
        //CREACIÓN DEL TABLERO
        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t.length; j++) {
                //CREACIÓN DE CADA CASILLA
                t[i][j]=new Casilla(i,j);
                //ASOCIAMOS GESTOR DE EVENTOS A CADA CASILLA
                t[i][j].addActionListener(listener);
                
                //COLOREADO DE LAS CASILLAS
                if(i%2 != 0){
                    if(j%2 != 0){
                        t[i][j].setBackground(Color.red);
                    }else{
                        t[i][j].setBackground(Color.yellow);
                    }
                }
                if(i%2==0){
                    if(j%2 == 0){
                        t[i][j].setBackground(Color.red);
                    }else{
                        t[i][j].setBackground(Color.yellow);
                    }
                }

                
//*********************COLOCACIÓN PIEZAS INICIALES******************************************
                //Primera línea Negra
                if (i == 0){
                    if(j == 0 || j == 7){
                        t[i][j].p = new Torre("Torre", "Negro","/img/TorreNegra.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 1 || j == 6){
                        t[i][j].p = new Caballo("Caballo", "Negro","/img/CaballoNegro.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 2 || j == 5){
                        t[i][j].p = new Alfil("Alfil", "Negro","/img/AlfilNegro.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 3){
                        t[i][j].p = new Reina("Reina", "Negro","/img/ReinaNegra.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 4){
                        t[i][j].p = new Rey("Rey", "Negro","/img/ReyNegro.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                }
                //Línea Peones Negra
                if (i == 1){
                    t[i][j].p = new Peon("Peon", "Negro","/img/PeonNegro.png");
                    t[i][j].setIcon(t[i][j].p.imagen);
                    t[i][j].p.reescalarImagen(t[i][j]);
                }
                //Línea Peones Blanca
                if (i == 6){
                    t[i][j].p = new Peon("Peon", "Blanco","/img/PeonBlanco.png");
                    t[i][j].setIcon(t[i][j].p.imagen);
                    t[i][j].p.reescalarImagen(t[i][j]);
                }
                //Primera Línea Blanca
                if (i == 7){
                    if(j == 0 || j == 7){
                        t[i][j].p = new Torre("Torre", "Blanco","/img/TorreBlanca.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 1 || j == 6){
                        t[i][j].p = new Caballo("Caballo", "Blanco","/img/CaballoBlanco.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 2 || j == 5){
                        t[i][j].p = new Alfil("Alfil", "Blanco","/img/AlfilBlanco.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 3){
                        t[i][j].p = new Reina("Reina", "Blanco","/img/ReinaBlanca.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                    if (j == 4){
                        t[i][j].p = new Rey("Rey", "Blanco","/img/ReyBlanco.png");
                        t[i][j].setIcon(t[i][j].p.imagen);
                        t[i][j].p.reescalarImagen(t[i][j]);
                    }
                }
            }
        }
    }
    
    public void piezapulsada (Casilla x){
        aux =  x;
        comprobarpieza(x);
    }
    
    public void mover (Casilla y){
        if(y.p == null){
            y.p = aux.p;
            Reemplazar(y,t[aux.x][aux.y]);
            activartablero();
        }
        else if (compararcolor(y,aux) != true){
            y.p = null;
            y.p = aux.p;
            Reemplazar(y,t[aux.x][aux.y]);
            activartablero();
        } else{
            aux = null;
            activartablero();
        }
        
    }
    
    public void Reemplazar(Casilla y, Casilla x){
        x.p=null;
        x.setIcon(null);
        aux=null;
        y.setIcon(y.p.imagen);
        y.p.reescalarImagen(y);
    }
    
    public boolean compararcolor(Casilla y, Casilla x){
        boolean comprobacion = false;
            if(y.p.color.equals(x.p.color)){
                comprobacion = true;
            }
        
        return comprobacion;
    }
    
    public void comprobarpieza(Casilla casillaActual){
        int coordx = casillaActual.x;
        int coordy = casillaActual.y;
        
        ArrayList <Point> movs = new ArrayList();
        movs = casillaActual.p.movValidos(1, 1);
        
        System.out.println("MovimientoValido.x = " + movs.get(0).x + ", MovimientoValido.y = " + movs.get(0).y);
        
        /*
        if(casillaActual.p.tipo.equals("Peon")){
            for (int i = 0; i < t.length; i++) {
                for (int j = 0; j < t.length; j++) {
                    t[i][j].setEnabled(false);
                }
            }
            if(casillaActual.p.color.equals("Blanco")){
                t[coordx][coordy].setEnabled(true);
                t[coordx-1][coordy].setEnabled(true);
            }else{
                t[coordx][coordy].setEnabled(true);
                t[coordx+1][coordy].setEnabled(true);
            }
        }
        if(casillaActual.p.tipo.equals("Caballo")){
            for (int i = 0; i < t.length; i++) {
                for (int j = 0; j < t.length; j++) {
                    t[i][j].setEnabled(false);
                }
            }
            t[coordx][coordy].setEnabled(true);
            t[coordx-3][coordy+1].setEnabled(true);
            t[coordx-3][coordy-1].setEnabled(true);
            t[coordx+3][coordy+1].setEnabled(true);
            t[coordx+3][coordy-1].setEnabled(true);
            t[coordx-1][coordy+3].setEnabled(true);
            t[coordx-1][coordy-3].setEnabled(true);
            t[coordx+1][coordy+3].setEnabled(true);
            t[coordx+1][coordy-3].setEnabled(true);
        }
        /*
        //CODIGO PROVISIONAL
        if(casillaActual.p.tipo.equals("Torre")){
            for (int i = 0; i < t.length; i++) {
                for (int j = 0; j < t.length; j++) {
                    t[i][j].setEnabled(false);
                }
            }
            t[coordx][coordy].setEnabled(true);
            
        }
        if(casillaActual.p.tipo.equals("Alfil")){
            for (int i = 0; i < t.length; i++) {
                for (int j = 0; j < t.length; j++) {
                    t[i][j].setEnabled(false);
                }
            }
            t[coordx][coordy].setEnabled(true);
        }
        if(casillaActual.p.tipo.equals("Rey")){
            for (int i = 0; i < t.length; i++) {
                for (int j = 0; j < t.length; j++) {
                    t[i][j].setEnabled(false);
                }
            }
            t[coordx][coordy].setEnabled(true);
        }
        if(casillaActual.p.tipo.equals("Reina")){
            for (int i = 0; i < t.length; i++) {
                for (int j = 0; j < t.length; j++) {
                    t[i][j].setEnabled(false);
                }
            }
            t[coordx][coordy].setEnabled(true);
        }*/
    
    }
    
    public void activartablero(){
        for (int i = 0; i < t.length; i++) {
                for (int j = 0; j < t.length; j++) {
                    t[i][j].setEnabled(true);
                }
            }
    }

}


