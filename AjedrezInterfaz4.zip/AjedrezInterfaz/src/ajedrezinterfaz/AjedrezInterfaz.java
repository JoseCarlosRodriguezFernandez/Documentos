package ajedrezinterfaz;

import java.awt.*;
import javax.swing.*;

public class AjedrezInterfaz extends JFrame{

    static Tablero m = new Tablero();
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Ajedrez");
        frame.setSize(640,640);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        JPanel panel = new JPanel();
        
        frame.add(panel);
        panel.setLayout(new GridLayout(m.filascolumnas, m.filascolumnas));
    
        for (int i = 0; i < m.filascolumnas; i++) {
            for (int j = 0; j < m.filascolumnas; j++) {
                panel.add(m.t[i][j]);
                
            }
        
        }
        
        frame.setVisible(true);
    
        }
    
}
