package ajedrezinterfaz;

import java.awt.Point;
import java.util.ArrayList;

public class Caballo extends Pieza{
 
    
    Caballo(String tipo, String color, String ruta){
        super(tipo, color, ruta);
    }

    @Override
    public ArrayList<Point> movValidos(int posX, int posY) {
        ArrayList <Point> movimientos = new ArrayList();

            if(posX+2 < AjedrezInterfaz.m.filascolumnas && posY+1 < AjedrezInterfaz.m.filascolumnas){
                Point mov = new Point(posX+2, posY+1);
                movimientos.add(mov);
            }
            if(posX+2 < AjedrezInterfaz.m.filascolumnas && posY-1 >= 0){
                Point mov = new Point(posX+2, posY-1);
                movimientos.add(mov);
            }
            if(posX-2 >= 0 && posY+1 < AjedrezInterfaz.m.filascolumnas){
                Point mov = new Point(posX-2, posY+1);
                movimientos.add(mov);
            }
            if(posX-2 >=0 && posY-1 >= 0){
                Point mov = new Point(posX-2, posY-1);
                movimientos.add(mov);
            }
            if(posX+1 < AjedrezInterfaz.m.filascolumnas && posY+2 < AjedrezInterfaz.m.filascolumnas){
                Point mov = new Point(posX+1, posY+2);
                movimientos.add(mov);
            }
            if(posX+1 < AjedrezInterfaz.m.filascolumnas && posY-2 >= 0){
                Point mov = new Point(posX+1, posY-2);
                movimientos.add(mov);
            }
            if(posX-1 >= 0 && posY+2 < AjedrezInterfaz.m.filascolumnas){
                Point mov = new Point(posX-1, posY+2);
                movimientos.add(mov);
            }
            if(posX-1 >=0 && posY-2 >= 0){
                Point mov = new Point(posX-1, posY-2);
                movimientos.add(mov);
            }
            
            
            
        return (movimientos);
    
    }
}
    

