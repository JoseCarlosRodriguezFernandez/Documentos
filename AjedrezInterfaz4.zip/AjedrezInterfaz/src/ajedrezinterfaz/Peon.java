package ajedrezinterfaz;

import java.awt.Point;
import java.util.ArrayList;

public class Peon extends Pieza{

    Peon(String tipo, String color, String ruta){
        super(tipo, color, ruta);
    }
    
    @Override
    public ArrayList <Point> movValidos(int posX, int posY){
        ArrayList <Point> movimientos = new ArrayList();
        if (this.color.equals("Blanco")){
            if(posX-1 >= 0){
                Point mov1 = new Point(posX-1, posY);
                movimientos.add(mov1);
            }
        }
        if (this.color.equals("Negro")){
            if(posX+1 < AjedrezInterfaz.m.filascolumnas){
                Point mov1 = new Point(posX+1, posY);
                movimientos.add(mov1);
            }
        }
        
        return (movimientos);
        
    }
    
}
