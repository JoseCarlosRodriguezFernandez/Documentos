package ajedrezinterfaz;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;

public abstract class Pieza {
    String tipo;
    String color;
    ImageIcon imagen;
    String ruta;
    

    Pieza(String tipo, String color, String ruta) {
        this.tipo = tipo;
        this.color = color;
        this.ruta = ruta;
        this.imagen = new ImageIcon(getClass().getResource(ruta));
    }
    
    public void reescalarImagen(JButton boton){
        Image img = imagen.getImage();
        Image otraimg = img.getScaledInstance(55,55,java.awt.Image.SCALE_SMOOTH);
        ImageIcon otroicon = new ImageIcon(otraimg);
        boton.setIcon(otroicon);
    }
    
    public abstract ArrayList <Point> movValidos(int posX, int posY);
}
