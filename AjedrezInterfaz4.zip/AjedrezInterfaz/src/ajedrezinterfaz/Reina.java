package ajedrezinterfaz;

import java.awt.Point;
import java.util.ArrayList;

public class Reina extends Pieza{
    

    
    Reina(String tipo, String color, String ruta){
        super(tipo, color, ruta);
    }

    @Override
    public ArrayList<Point> movValidos(int posX, int posY) {
        ArrayList <Point> movimientos = new ArrayList();
        
        for (int i = 0; i < AjedrezInterfaz.m.filascolumnas; i++) {
 
            if(posX+i < AjedrezInterfaz.m.filascolumnas && posY+i <AjedrezInterfaz.m.filascolumnas){
                Point mov = new Point(posX+i, posY+i);  
                movimientos.add(mov);
            }
            if(posX-i >= 0 && posY-i >= 0){
                Point mov = new Point(posX-i, posY-i);  
                movimientos.add(mov);
            }
            if(posX+i < AjedrezInterfaz.m.filascolumnas && posY-i >= 0){
                Point mov = new Point(posX+i, posY-i);  
                movimientos.add(mov);
            }
            if(posX-i >= 0 && posY+i < AjedrezInterfaz.m.filascolumnas){
                Point mov = new Point(posX-i, posY+i);  
                movimientos.add(mov);
            }
            if(posY+i <AjedrezInterfaz.m.filascolumnas){
                Point mov = new Point(posX, posY+i);  
                movimientos.add(mov);
            }
            if(posY-i >= 0){
                Point mov = new Point(posX, posY-i);  
                movimientos.add(mov);
            }
            if(posX+i < AjedrezInterfaz.m.filascolumnas){
                Point mov = new Point(posX+i, posY);  
                movimientos.add(mov);
            }
            if(posX-i >= 0){
                Point mov = new Point(posX-i, posY);  
                movimientos.add(mov);
            }
            
        
        }    
        
        return (movimientos);
    }
}
