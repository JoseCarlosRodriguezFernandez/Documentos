package ajedrezinterfaz;

import java.awt.*;
import javax.swing.*;

public class AjedrezInterfaz extends JFrame{

    static Tablero m = new Tablero();
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Ajedrez");
        frame.setSize(940,640);
        frame.setLayout(new BorderLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        
        JPanel panel1 = new JPanel();
        panel1.setPreferredSize(new Dimension(150,640));
        //panel1.setLayout(new GridLayout(m.filascolumnas, m.filascolumnas));
        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(640,640));
        panel.setLayout(new GridLayout(m.filascolumnas, m.filascolumnas));
        JPanel panel2 = new JPanel();
        panel2.setPreferredSize(new Dimension(150,640));
        //panel2.setLayout(new GridLayout(m.filascolumnas, m.filascolumnas));
        
        frame.add(panel1, BorderLayout.LINE_START);
        frame.add(panel, BorderLayout.CENTER);
        frame.add(panel2, BorderLayout.LINE_END);

    
        for (int i = 0; i < m.filascolumnas; i++) {
            for (int j = 0; j < m.filascolumnas; j++) {
                panel.add(m.t[i][j]);
            }
        
        }
        
        frame.setVisible(true);
        
        }
    
}
