package ajedrezinterfaz;

import java.awt.Point;
import java.util.ArrayList;

public class Peon extends Pieza{

    Peon(String tipo, String color, String ruta){
        super(tipo, color, ruta);
    }
    
    @Override
    public ArrayList <Point> movValidos(int posX, int posY){
        ArrayList <Point> movimientos = new ArrayList();
        if (this.color.equals("Blanco")){
            if(posX-1 >= 0){
                if(AjedrezInterfaz.m.t[posX-1][posY].p == null){
                    Point mov1 = new Point(posX-1, posY);
                    movimientos.add(mov1);
                }
            }
            if(posY-1 >= 0 && posX-1 >= 0){
                if(AjedrezInterfaz.m.t[posX-1][posY-1].p != null){
                    Point mov1 = new Point(posX-1, posY-1);
                    movimientos.add(mov1);
                }
            }
            if(posY+1 < AjedrezInterfaz.m.filascolumnas && posX-1 >= 0){
                if(AjedrezInterfaz.m.t[posX-1][posY+1].p != null){
                    Point mov1 = new Point(posX-1, posY+1);
                    movimientos.add(mov1);
                }
            }
            
        }
        if (this.color.equals("Negro")){
            if(posX+1 < AjedrezInterfaz.m.filascolumnas){
                if(AjedrezInterfaz.m.t[posX+1][posY].p == null){
                    Point mov1 = new Point(posX+1, posY);
                    movimientos.add(mov1);
                }
            }
            if(posY-1 >= 0 && posX+1 < AjedrezInterfaz.m.filascolumnas){
                if(AjedrezInterfaz.m.t[posX+1][posY-1].p != null){
                    Point mov1 = new Point(posX+1, posY-1);
                    movimientos.add(mov1);
                }
            }
            if(posY+1 < AjedrezInterfaz.m.filascolumnas && posX+1 < AjedrezInterfaz.m.filascolumnas){
                if(AjedrezInterfaz.m.t[posX+1][posY+1].p != null){
                    Point mov1 = new Point(posX+1, posY+1);
                    movimientos.add(mov1);
                }
            }
        }
        
        return (movimientos);
        
    }
    
}
