package ajedrezinterfaz;

import java.awt.Point;
import java.util.ArrayList;

public class Rey extends Pieza{
    
    
    Rey(String tipo, String color, String ruta){
        super(tipo, color, ruta);
    }

    @Override
    public ArrayList<Point> movValidos(int posX, int posY) {
        ArrayList <Point> movimientos = new ArrayList();
            if(posX-1 >= 0){
                Point mov1 = new Point(posX-1, posY);
                movimientos.add(mov1);
            }
            if(posX+1 < AjedrezInterfaz.m.filascolumnas){
                Point mov1 = new Point(posX+1, posY);
                movimientos.add(mov1);
            }
            if(posY-1 >= 0){
                Point mov1 = new Point(posX, posY-1);
                movimientos.add(mov1);
            }
            if(posY+1 < AjedrezInterfaz.m.filascolumnas){
                Point mov1 = new Point(posX, posY+1);
                movimientos.add(mov1);
            }
            if(posX+1 < AjedrezInterfaz.m.filascolumnas && posY+1 <AjedrezInterfaz.m.filascolumnas){
                Point mov = new Point(posX+1, posY+1);  
                movimientos.add(mov);
            }
            if(posX-1 >= 0 && posY-1 >= 0){
                Point mov = new Point(posX-1, posY-1);  
                movimientos.add(mov);
            }
            if(posX+1 < AjedrezInterfaz.m.filascolumnas && posY-1 >= 0){
                Point mov = new Point(posX+1, posY-1);  
                movimientos.add(mov);
            }
            if(posX-1 >= 0 && posY+1 < AjedrezInterfaz.m.filascolumnas){
                Point mov = new Point(posX-1, posY+1);  
                movimientos.add(mov);
            }
            
        
        return (movimientos);
    }
    
    
}
