package ajedrezinterfaz;

import java.awt.Point;
import java.util.ArrayList;

public class Alfil extends Pieza{

    Alfil(String tipo, String color, String ruta){
        super(tipo, color, ruta);
    }

    @Override
    public ArrayList<Point> movValidos(int posX, int posY) {
            ArrayList <Point> movimientos = new ArrayList();
            /*
                ** El Alfil comprueba las 4 diagonales hasta los limites de la matriz
                ** Si encuentra una ficha de por medio, deja de incluir esos movimientos al Array.
            */
        for (int i = 1; i < AjedrezInterfaz.m.filascolumnas; i++) {
            if(posX+i < AjedrezInterfaz.m.filascolumnas && posY+i <AjedrezInterfaz.m.filascolumnas){
                if(AjedrezInterfaz.m.t[posX+i][posY+i].p == null){
                    Point mov = new Point(posX+i, posY+i);
                    movimientos.add(mov);
                }else{
                    Point mov = new Point(posX+i, posY+i);
                    movimientos.add(mov);
                    i=AjedrezInterfaz.m.filascolumnas + 1;
                }
            }
        }
        for (int i = 1; i < AjedrezInterfaz.m.filascolumnas; i++) {
            if(posX-i >= 0 && posY-i >= 0){ 
                if(AjedrezInterfaz.m.t[posX-i][posY-i].p == null){
                    Point mov = new Point(posX-i, posY-i);
                    movimientos.add(mov);
                }else{
                    Point mov = new Point(posX-i, posY-i);
                    movimientos.add(mov);
                    i=AjedrezInterfaz.m.filascolumnas + 1;
                }
            }  
        }
        for (int i = 1; i < AjedrezInterfaz.m.filascolumnas; i++) {
            if(posX+i < AjedrezInterfaz.m.filascolumnas && posY-i >= 0){
                if(AjedrezInterfaz.m.t[posX+i][posY-i].p == null){
                    Point mov = new Point(posX+i, posY-i);
                    movimientos.add(mov);
                }else{
                    Point mov = new Point(posX+i, posY-i);
                    movimientos.add(mov);
                    i=AjedrezInterfaz.m.filascolumnas + 1;
                }
            }
        }
            
        for (int i = 1; i < AjedrezInterfaz.m.filascolumnas; i++) {
            if(posX-i >= 0 && posY+i < AjedrezInterfaz.m.filascolumnas){
                if(AjedrezInterfaz.m.t[posX-i][posY+i].p == null){
                    Point mov = new Point(posX-i, posY+i);
                    movimientos.add(mov);
                }else{
                    Point mov = new Point(posX-i, posY+i);
                    movimientos.add(mov);
                    i=AjedrezInterfaz.m.filascolumnas + 1;
                }
            }
        }
            
        return (movimientos);
    }

}
