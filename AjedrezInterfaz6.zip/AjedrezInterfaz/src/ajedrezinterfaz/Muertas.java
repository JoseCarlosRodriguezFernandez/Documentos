package ajedrezinterfaz;

import java.awt.*;
import javax.swing.*;

public class Muertas extends JLabel{
    
    Muertas(){
        ImageIcon imagen;
    }
}
