package ajedrezinterfaz;

import java.awt.*;
import javax.swing.*;

public class Negrasmuertas {

    public int filas = 8;
    public int columnas = 2;
    public Muertas n [][] = new Muertas[filas][columnas];
    
    Negrasmuertas(){
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                n[i][j] = new Muertas();
            }
        }
    }
}
