package ajedrezinterfaz;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class AjedrezInterfaz extends JFrame{

    static Tablero m = new Tablero();
    static Negrasmuertas n = new Negrasmuertas();
    static Blancasmuertas b = new Blancasmuertas();
    static JLabel turnos = new JLabel();
    static Color fondo = new Color(240, 178, 122);
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Ajedrez");
        frame.setSize(940,640);
        frame.setLayout(new BorderLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        
        JPanel panelup = new JPanel();
        panelup.setPreferredSize(new Dimension(640,40));
        panelup.setLayout(new BorderLayout());
        panelup.setBackground(fondo);
        JPanel panelizq = new JPanel();
        panelizq.setPreferredSize(new Dimension(150,640));
        panelizq.setLayout(new GridLayout(8, 2));
        panelizq.setBackground(fondo);
        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(640,640));
        panel.setLayout(new GridLayout(m.filascolumnas, m.filascolumnas));
        JPanel panelder = new JPanel();
        panelder.setPreferredSize(new Dimension(150,640));
        panelder.setLayout(new GridLayout(8, 2));
        panelder.setBackground(fondo);
        
        frame.add(panelup, BorderLayout.NORTH);
        frame.add(panelizq, BorderLayout.LINE_START);
        frame.add(panel, BorderLayout.CENTER);
        frame.add(panelder, BorderLayout.LINE_END);

        JLabel negras = new JLabel();
        JLabel blancas = new JLabel();
        
        Border border = negras.getBorder();
        Border margin = new EmptyBorder(0,10,0,10);
        negras.setBorder(new CompoundBorder(border, margin));
        blancas.setBorder(new CompoundBorder(border, margin));
        Border margenup = new EmptyBorder(0, 235, 0, 225);
        turnos.setBorder(new CompoundBorder(border, margenup));
        
        panelup.add(negras, BorderLayout.EAST);
        panelup.add(blancas, BorderLayout.WEST);
        panelup.add(turnos, BorderLayout.CENTER);
        negras.setText("Fichas Negras Muertas");
        blancas.setText("Fichas Blancas Muertas");
        turnos.setText("COMIENZAN LAS BLANCAS");
        
        for (int i = 0; i < m.filascolumnas; i++) {
            for (int j = 0; j < m.filascolumnas; j++) {
                panel.add(m.t[i][j]);
            }
        }
        for (int i = 0; i < n.filas; i++) {
            for (int j = 0; j < n.columnas; j++) {
                panelder.add(n.n[i][j]);
            }
        }
        for (int i = 0; i < b.filas; i++) {
            for (int j = 0; j < b.columnas; j++) {
                panelizq.add(b.b[i][j]);
            }
            
        }
        frame.setVisible(true);
        
        }
    
}
