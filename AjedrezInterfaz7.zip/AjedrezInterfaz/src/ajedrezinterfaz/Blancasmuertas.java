package ajedrezinterfaz;

import javax.swing.*;

public class Blancasmuertas {
    
    public int filas = 8;
    public int columnas = 2;
    public Muertas b [][] = new Muertas[filas][columnas];
    public ImageIcon imagen;
    
    Blancasmuertas(){
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                b[i][j] = new Muertas();
            }
        }
    }
    
}
