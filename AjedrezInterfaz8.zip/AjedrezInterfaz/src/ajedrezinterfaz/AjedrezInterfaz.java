package ajedrezinterfaz;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class AjedrezInterfaz extends JFrame{

    static Tablero m;
    static Negrasmuertas n;
    static Blancasmuertas b;
    static JLabel turnos;
    static Color fondo = new Color(240, 178, 122);
    static JFrame frame;
    static boolean parar=false;
    static boolean terminar=false;
    
    public static void main(String[] args) throws InterruptedException {
        
        /********************** CREACIÓN DE LA INTERFAZ ***************************/
       do{
           frame = new JFrame("Ajedrez");
           parar=false;
           terminar=false;
           m = new Tablero();
           n = new Negrasmuertas();
           b = new Blancasmuertas();
           turnos = new JLabel();
           
            frame.setSize(940,640);
            frame.setLayout(new BorderLayout());
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setResizable(false);
            frame.setLocationRelativeTo(null);

            //Panel de arriba
            JPanel panelup = new JPanel();
            panelup.setPreferredSize(new Dimension(640,40));
            panelup.setLayout(new BorderLayout());
            panelup.setBackground(fondo);
            //Panel de la izquierda (fichas blancas muertas)
            JPanel panelizq = new JPanel();
            panelizq.setPreferredSize(new Dimension(150,640));
            panelizq.setLayout(new GridLayout(8, 2));
            panelizq.setBackground(fondo);
            //Panel en el que situamos el tablero de ajedrez
            JPanel panel = new JPanel();
            panel.setPreferredSize(new Dimension(640,640));
            panel.setLayout(new GridLayout(m.filascolumnas, m.filascolumnas));
            //Panel de la derecha (fichas negras muertas)
            JPanel panelder = new JPanel();
            panelder.setPreferredSize(new Dimension(150,640));
            panelder.setLayout(new GridLayout(8, 2));
            panelder.setBackground(fondo);

            //Colocamos los paneles usando un BorderLayout
            frame.add(panelup, BorderLayout.NORTH);
            frame.add(panelizq, BorderLayout.LINE_START);
            frame.add(panel, BorderLayout.CENTER);
            frame.add(panelder, BorderLayout.LINE_END);

            //Creación de Label para los textos del panel superior
            JLabel negras = new JLabel();
            JLabel blancas = new JLabel();

            //Añadimos márgenes al panel superior para que quede "bonito"
            Border border = negras.getBorder();
            Border margin = new EmptyBorder(0,10,0,10);
            negras.setBorder(new CompoundBorder(border, margin));
            blancas.setBorder(new CompoundBorder(border, margin));
            Border margenup = new EmptyBorder(0, 235, 0, 225);
            turnos.setBorder(new CompoundBorder(border, margenup));

            //Los añadimos al panel superior con un BorderLayout
            panelup.add(negras, BorderLayout.EAST);
            panelup.add(blancas, BorderLayout.WEST);
            panelup.add(turnos, BorderLayout.CENTER);
            negras.setText("Fichas Negras Muertas");
            blancas.setText("Fichas Blancas Muertas");
            turnos.setText("COMIENZAN LAS BLANCAS");


            //Bucle que añade el tablero al panel central
            for (int i = 0; i < m.filascolumnas; i++) {
                for (int j = 0; j < m.filascolumnas; j++) {
                    panel.add(m.t[i][j]);
                }
            }
            //Bucle que añade el panel para las fichas negras muertas
            for (int i = 0; i < n.filas; i++) {
                for (int j = 0; j < n.columnas; j++) {
                    panelder.add(n.n[i][j]);
                }
            }
            //Bucle que añade el panel para las fichas blancas muertas
            for (int i = 0; i < b.filas; i++) {
                for (int j = 0; j < b.columnas; j++) {
                    panelizq.add(b.b[i][j]);
                }

            }

            //Mostramos el panel
            frame.setVisible(true);
            while(parar==false){
                System.out.print("");
            }
       }while(terminar==false);
       
       System.exit(0);
        
    }
    
    
}