package ajedrezinterfaz;

import javax.swing.*;


public class Casilla extends JButton{
    public Pieza p = null;
    public int x;
    public int y;

    Casilla (int x, int y){
        this.x = x;
        this.y = y;
    }
    
    Casilla (Casilla n){
        this.p = n.p;
        this.x = n.x;
        this.y = n.y;
    }
    
}
