package ajedrezinterfaz;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Muertas extends JLabel{
    ImageIcon imagen;
    
    Muertas(){
        imagen = null;
    }
    
    public void reescalarImagen(JLabel label){
        Image img = imagen.getImage();
        Image otraimg = img.getScaledInstance(55,55,java.awt.Image.SCALE_SMOOTH);
        ImageIcon otroicon = new ImageIcon(otraimg);
        label.setIcon(otroicon);
    }
}
