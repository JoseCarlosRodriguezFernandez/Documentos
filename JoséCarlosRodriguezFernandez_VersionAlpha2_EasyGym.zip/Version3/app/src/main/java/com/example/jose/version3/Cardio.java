package com.example.jose.version3;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Cardio extends AppCompatActivity {

    /**
     * Activity que muestra las actividades referente al cardio
     *
     * @param: imagen: se refiere a la imagen que va a salir en la activity.
     * @param: minutos: hace referencia a los minutos del Asyntask.
     * @param: segundos: hace referencia a los segundos del Asyntask.
     * @param: crono: Referencia la texto que usará el Asyntask.
     * @param: time: Referencia al tiempo que el Asyntask va a estar ejecutandose.
     */
    static ImageView imagen;
    static int minutos = 0;
    static int segundos = 0;
    static TextView crono;
    static EditText tiempo;
    static int time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardio);
        ArrayAdapter<CharSequence> adapter;

        //Les indicamos a las variables que Views van a utilizar:
        /**
         * @param tiempo: es el texto donde se muestra el tiempo que va a actuar el cronometro
         * @param enunciado: texto a la izquierda del boton
         * @param cronometro: boton que inicializa el corno
         * @param spinner: permite elegir entre los distintos ejercicios
         * @param crono: el texto de los minutos y segundos.
         */
        tiempo = (EditText) findViewById(R.id.tiempocardio);
        TextView enunciado = (TextView) findViewById(R.id.enunciado1);
        Button cronometro = (Button) findViewById(R.id.crono1);
        Spinner spinner = (Spinner) findViewById(R.id.cardiospinner);
        crono = (TextView) findViewById(R.id.minutosview);

        //Creamos un adaptar, al que le pasamos por parametros un Array con los nombres que utilizará y un estilo:
        adapter = ArrayAdapter.createFromResource(this, R.array.ejescardio, R.layout.spinner_item_spinner);
        spinner.setAdapter(adapter);

        //Inicializamos las variables:
        enunciado.setText("Inserte minutos");
        imagen = findViewById(R.id.imagejerc);
        crono.setText(minutos + " minutos " + segundos + " segundos");

        //Creamos el metodo del Spinner que nos permite modificar las vistas dependiendo de la elección:
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String item = parent.getItemAtPosition(position).toString();
                //Depende de cual elijamos, cambiará una imagen u otra, y el tiempo del Asyntask cambiará a -1 para forzar su parado.
                switch (item) {
                    case "Cinta":
                        imagen.setImageResource(R.drawable.correr);
                        time = -1;
                        break;
                    case "Bicicleta":
                        imagen.setImageResource(R.drawable.bicicleta);
                        time = -1;
                        break;
                    case "Eliptica":
                        imagen.setImageResource(R.drawable.eliptica);
                        time = -1;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    //Funcion que provoca un segundo de parada en el cronometro

    /**
     * Determina un tiempo de parada de 1 segundo.
     */
    private void tiempoespera(){
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {}
    }

    /**
     * Asyntask que permite la ejecución del cronometro en 2º plano.
     */
    //Asyntask que permite el funcionamiento del cronometro:
    private class Cronometro extends AsyncTask<Void, Integer, Boolean>{
        /**
         * Lo que se ejecuta en background.
         * @param voids
         * @return ejecucion: será true o false dependiendo de si la actividad se ha ejecutado con exito o no.
         */
        @Override
        protected Boolean doInBackground(Void... voids) {
            //Esto es lo que se realiza en Background de la ejecución:
            Boolean ejecucion = true;
            time = Integer.parseInt(tiempo.getText().toString());
            time = time*60;
            if (time <= 0){
                this.cancel(true);
                ejecucion = false;
            }

            for(int i=0; i<time; i++) {
                    tiempoespera();
                    publishProgress();

                if(isCancelled() == true){
                    ejecucion = false;
                    break;
                }
            }
            return ejecucion;
        }

        /**
         * Actualiza los datos en la interfaz
         * @param values
         */
        @Override
        protected void onProgressUpdate(Integer... values) {
            //Se cambia el valor de las variables y del Texto del cronómetro:
            segundos = segundos + 1;
            if(segundos == 60){
                segundos = 0;
                minutos = minutos + 1;
            }
            crono.setText(minutos + " minutos " + segundos + " segundos");

        }

        /**
         * Antes de la ejecucion:
         */
        @Override
        protected void onPreExecute() {
            //Se prepara el cronómetro para su uso:
            minutos = 0;
            segundos = 0;
            crono.setText(minutos + " minutos " + segundos + " segundos");
        }

        /**
         * Despues de la ejecucion
         * @param result
         */
        @Override
        protected void onPostExecute(Boolean result) {
            //Cuando se ejecuta, te envia un mensaje de éxito y se termina la ejecución del Asyntask
            if (result == true) {
                Toast finejercicio = Toast.makeText(getApplicationContext(), "SE ACABÓ, A DESCANSAR", Toast.LENGTH_SHORT);
                finejercicio.show();
            }
        }

        /**
         * Al cancelar la ejecucion
         */
        @Override
        protected void onCancelled() {
            //Lo que provoca la cancelación del Asyntask
            time = -1;
        }
    }

    /**
     * Metodo onClick de los botones
     * Si pulsas el boton de iniciar, inicia el Asyntask
     * Si pulsas el de parada, cancela la ejecución del Aynstask
     * @param view
     */
    //Dependiendo de si pulsamos el boton de inicio o pausa, iniciará el Aynstask o forzará su parado:
    public void onClick(View view) {
        Cronometro tiempoejercicio = new Cronometro();
        switch (view.getId()) {
            case R.id.crono1:
                //Botón de inicio
                tiempoejercicio.execute();
                break;
            case R.id.crono2:
                //Botón de parada
                tiempo.setText("0");
                tiempoejercicio.cancel(true);
                break;
        }
    }
}