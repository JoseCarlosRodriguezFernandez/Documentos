package com.example.jose.version3;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class EjerciciosActivity extends AppCompatActivity {

    /**
     * Acitivity que muestra las actividades de los diferentes músculos.
     *
     * @param: explicacion: muestra el texto de explicacion de cada ejercicio
     * @param: imagen: muestra la imagen del ejercicio
     * @param: database: recoge la instancia de la base de datos de firebase
     * @param: myref: recoge una referencia de la base de datos de firebase, en este caso, los musculos a ejercitar
     */
    static TextView explicacion;
    static ImageView imagen;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    static DatabaseReference myRef;

    /**
     * Se genera a la hora de crear la activity
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicios);
        //parametros y tipos reciben el String pasado desde el menú, y dependiendo del tipo de String, se mostrarán unas imagenes/descripciones u otras, a parte de cambiar el contenido del Spinner.
        Bundle parametros = this.getIntent().getExtras();
        String tipo = parametros.getString("tipo");

        //En este switch se controla qué imagenes, spinner y texto aparecerán
        //Como en cada músculo se seguirá el mismo proceso, explicaré "ESPALDA". El resto, como he dicho , sigue el mismo proceso:
        switch (tipo){
            case "espalda":
                //Coge la referencia espalda de la base de datos:
                myRef = database.getReference("espalda");
                //Se crea el spinner, teniendo en cuenta los datos de la Espalda:
                ArrayAdapter<CharSequence> adapter;
                Spinner spinner = (Spinner) findViewById(R.id.ejerciciospinner);
                adapter = ArrayAdapter.createFromResource(this, R.array.ejespaldas, R.layout.spinner_item_spinner);
                spinner.setAdapter(adapter);

                //Se inicializan las variables imagenes y explicacion:
                imagen = findViewById(R.id.imagejerc);
                explicacion = findViewById(R.id.textexplic);

                //Creamos el metodo del Spinner que nos permite modificar las vistas dependiendo de la elección:
                spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String item = parent.getItemAtPosition(position).toString();

                        switch (item) {
                            //Por cáda ejercicio realiza lo siguiente:
                            //Recibe el nombre del ejercicio:
                            case "Dominadas":
                                //Busca la referencia en la base de datos:
                                myRef.child("Dominadas").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        //Obtiene el texto y se la pasa a la View que hace referencia al texto:
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                //Depende del ejercicio que escoja, mostrará una imagen u otra
                                imagen.setImageResource(R.drawable.dominadas);
                                break;

                            /**
                             * SE REPITE EL MISMO PROCESO DURANTE TODOS LOS MÚSCULOS Y TIPOS DE EJERCICIOS
                             */
                            case "Gironda":
                                myRef.child("Gironda").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.gironda);
                                break;
                            case "Remo":
                                myRef.child("Remo").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.remoespalda);
                                break;
                            case "Jalon al pecho":
                                myRef.child("jalon al pecho").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.jalonpecho);
                                break;
                            case "Peso muerto":
                                myRef.child("Peso muerto").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.pesomuerto);
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {}
                });
                break;
            case "hombro":
                myRef = database.getReference("hombro");
                ArrayAdapter<CharSequence> adapter2;
                Spinner spinner2 = (Spinner) findViewById(R.id.ejerciciospinner);
                adapter2 = ArrayAdapter.createFromResource(this, R.array.ejehombros, R.layout.spinner_item_spinner);
                spinner2.setAdapter(adapter2);

                imagen = findViewById(R.id.imagejerc);
                explicacion = findViewById(R.id.textexplic);

                spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String item = parent.getItemAtPosition(position).toString();

                        switch (item) {
                            case "Press militar":
                                myRef.child("Press militar").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.pressmilitar);
                                break;
                            case "Elevacion lateral":
                                myRef.child("Elevacion lateral").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.laterales);
                                break;
                            case "Elevacion frontal":
                                myRef.child("Elevacion frontal").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.frontales);
                                break;
                            case "Press arnold":
                                myRef.child("Press arnold").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.pressarnold);
                                break;
                            case "Pajaro":
                                myRef.child("Pajaro").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.pajaro);
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {}
                });
                break;
            case "pecho":
                myRef = database.getReference("pecho");
                ArrayAdapter<CharSequence> adapter3;
                Spinner spinner3 = (Spinner) findViewById(R.id.ejerciciospinner);
                adapter3 = ArrayAdapter.createFromResource(this, R.array.ejepechos, R.layout.spinner_item_spinner);
                spinner3.setAdapter(adapter3);

                imagen = findViewById(R.id.imagejerc);
                explicacion = findViewById(R.id.textexplic);

                spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String item = parent.getItemAtPosition(position).toString();

                        switch (item) {
                            case "Plano":
                                myRef.child("Plano").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.pechoplano);
                                break;
                            case "Superior":
                                myRef.child("Superior").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.pechosuperior);
                                break;
                            case "Inferior":
                                myRef.child("Inferior").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.pechoinferior);
                                break;
                            case "Contractor":
                                myRef.child("Contractor").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.contractor);
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {}
                });
                break;
            case "biceps":
                myRef = database.getReference("biceps");
                ArrayAdapter<CharSequence> adapter4;
                Spinner spinner4 = (Spinner) findViewById(R.id.ejerciciospinner);
                adapter4 = ArrayAdapter.createFromResource(this, R.array.ejebicepss, R.layout.spinner_item_spinner);
                spinner4.setAdapter(adapter4);

                imagen = findViewById(R.id.imagejerc);
                explicacion = findViewById(R.id.textexplic);

                spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String item = parent.getItemAtPosition(position).toString();

                        switch (item) {
                            case "Curl Biceps":
                                myRef.child("Curl Biceps").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.curlbiceps);
                                break;
                            case "Martillo":
                                myRef.child("Martillo").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.martillo);
                                break;
                            case "Concentrado":
                                myRef.child("Concentrado").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.concentrado);
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {}
                });
                break;
            case "triceps":
                myRef = database.getReference("triceps");
                ArrayAdapter<CharSequence> adapter5;
                Spinner spinner5 = (Spinner) findViewById(R.id.ejerciciospinner);
                adapter5 = ArrayAdapter.createFromResource(this, R.array.ejetricepss, R.layout.spinner_item_spinner);
                spinner5.setAdapter(adapter5);

                imagen = findViewById(R.id.imagejerc);
                explicacion = findViewById(R.id.textexplic);

                spinner5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String item = parent.getItemAtPosition(position).toString();

                        switch (item) {
                            case "Extension vertical":
                                myRef.child("Extension vertical").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.extensionvert);
                                break;
                            case "Polea":
                                myRef.child("Polea").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.polea);
                                break;
                            case "Fondo":
                                myRef.child("Fondo").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.fondotriceps);
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {}
                });
                break;
            case "piernas":
                myRef = database.getReference("pierna");
                ArrayAdapter<CharSequence> adapter6;
                Spinner spinner6 = (Spinner) findViewById(R.id.ejerciciospinner);
                adapter6 = ArrayAdapter.createFromResource(this, R.array.ejepiernas, R.layout.spinner_item_spinner);
                spinner6.setAdapter(adapter6);

                imagen = findViewById(R.id.imagejerc);
                explicacion = findViewById(R.id.textexplic);

                spinner6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String item = parent.getItemAtPosition(position).toString();

                        switch (item) {
                            case "Sentadillas":
                                myRef.child("Sentadillas").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.sentadillas);
                                break;
                            case "Zancadas":
                                myRef.child("Zancadas").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.zancadas);
                                break;
                            case "Extension cuadriceps":
                                myRef.child("Extension cuadriceps").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.extensioncuadr);
                                break;
                            case "Femoral":
                                myRef.child("Femoral").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.femoral);
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {}
                });
                break;
            case "gemelos":
                myRef = database.getReference("gemelo");
                ArrayAdapter<CharSequence> adapter7;
                Spinner spinner7 = (Spinner) findViewById(R.id.ejerciciospinner);
                adapter7 = ArrayAdapter.createFromResource(this, R.array.ejegemelos, R.layout.spinner_item_spinner);
                spinner7.setAdapter(adapter7);

                imagen = findViewById(R.id.imagejerc);
                explicacion = findViewById(R.id.textexplic);

                spinner7.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String item = parent.getItemAtPosition(position).toString();

                        switch (item) {
                            case "De pie con barra":
                                myRef.child("De pie con barra").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.gemelos1);
                                break;
                            case "Sentado en maquina":
                                myRef.child("Sentado en maquina").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.gemelos2);
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {}
                });
                break;
            case "trapecio":
                myRef = database.getReference("trapecio");
                ArrayAdapter<CharSequence> adapter8;
                Spinner spinner8 = (Spinner) findViewById(R.id.ejerciciospinner);
                adapter8 = ArrayAdapter.createFromResource(this, R.array.ejetrapecios, R.layout.spinner_item_spinner);
                spinner8.setAdapter(adapter8);

                imagen = findViewById(R.id.imagejerc);
                explicacion = findViewById(R.id.textexplic);

                spinner8.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String item = parent.getItemAtPosition(position).toString();

                        switch (item) {
                            case "Encogimiento hombros":
                                myRef.child("Encogimiento hombros").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.trapecio1);
                                break;
                            case "Remo al menton":
                                myRef.child("Remo al menton").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.trapecio2);
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {}
                });
                break;
            case "abdominal":
                myRef = database.getReference("abdominal");
                ArrayAdapter<CharSequence> adapter9;
                Spinner spinner9 = (Spinner) findViewById(R.id.ejerciciospinner);
                adapter9 = ArrayAdapter.createFromResource(this, R.array.ejeabdominals, R.layout.spinner_item_spinner);
                spinner9.setAdapter(adapter9);

                imagen = findViewById(R.id.imagejerc);
                explicacion = findViewById(R.id.textexplic);

                spinner9.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String item = parent.getItemAtPosition(position).toString();

                        switch (item) {
                            case "Elevacion paralela":
                                myRef.child("Elevacion paralela").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.abdominal1);
                                break;
                            case "Elevacion suelo":
                                myRef.child("Elevacion suelo").getRef().addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        explicacion.setText(dataSnapshot.getValue(String.class));
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError){}
                                });
                                imagen.setImageResource(R.drawable.abdominal2);
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {}
                });
                break;
        }


    }
}
