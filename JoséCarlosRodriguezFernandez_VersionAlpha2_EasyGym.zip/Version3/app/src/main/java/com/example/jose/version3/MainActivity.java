package com.example.jose.version3;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    /**
     * En esta activity estamos generando los registros de usuarios usando la Base de datos Authenticator de Android Studio.
     */
    EditText editTextEmail, editTextPassword;
    Button buttonLogin, buttonRegister;

    FirebaseAuth.AuthStateListener mAuthListener;

    /**
     * Funcion que se ejecuta al iniciar la Activity
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /**
         * Variables:
         * editTextEmail: el texto del email
         * editTextPassword: el texto de la contraseña
         * buttonLogin: boton para logearse
         * buttonRegister: boton para registrarse
         */
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);

        buttonRegister.setOnClickListener(this);
        buttonLogin.setOnClickListener(this);

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if(user != null){
                    System.out.println("Sesión iniciada con email: "+ user.getEmail());
                }else{
                    System.out.println("No hay usuario");
                }
            }
        };

    }
    //Función que se encarga de registrar a los usiarios

    /**
     * Registra los usuarios en la base de datos en caso de que no existan ya dentro:
     * @param email
     * @param pass
     */
    private void registrar(String email, String pass){
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    //Muestra mensaje en caso de exito
                    Toast toastUsuarioCreado = Toast.makeText(getApplicationContext(), "Usuario creado correctamente", Toast.LENGTH_SHORT);
                    toastUsuarioCreado.show();
                }else{
                    //Muestra mensaje de error en caso de fallo
                    Toast toastUsuarioerror = Toast.makeText(getApplicationContext(), "No se ha podido crear usuario", Toast.LENGTH_SHORT);
                    toastUsuarioerror.show();
                }
            }
        });

    }

    /**
     * Comprueba los datos en la base de datos, si son correctos, pasa a la siguiente activity
     * @param email
     * @param pass
     */
    //Funcion que inicia la sesión y pasa al menú
    private void iniciarSesion(String email, String pass){
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    //Pasa al menú si el inicio de sesión ha sido un éxito
                    Intent intent = new Intent(getApplicationContext(), Menu.class);
                    startActivity(intent);
                }else{
                    //Muestra un mensaje de error si no ha podido iniciar la sesion
                    Toast toastsesioncerrada = Toast.makeText(getApplicationContext(), "Usuario o contraseña incorrectos.", Toast.LENGTH_SHORT);
                    toastsesioncerrada.show();
                }
            }
        });

    }

    /**
     * Metodo onClick de los botones.
     * Si pulsa el boton de inicio hace login
     * Si pulsa el boton de registro, intenta registrar el usuario y la contraseña en la BDD
     * @param view
     */
    //Se crean los metodos onClick de los botones, y dependiendo de cual pulses, será el de registro o inicio de sesion.
    @Override
    public void onClick(View view){
        String email = editTextEmail.getText().toString();
        String pass = editTextPassword.getText().toString();

        switch (view.getId()){
            case R.id.buttonLogin:
                iniciarSesion(email, pass);
                break;
            case R.id.buttonRegister:
                registrar(email, pass);
                break;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseAuth.getInstance().addAuthStateListener(mAuthListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(mAuthListener!=null){
            FirebaseAuth.getInstance().removeAuthStateListener(mAuthListener);
        }
    }

}
