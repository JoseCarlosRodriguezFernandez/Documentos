package com.example.jose.version3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;


public class Menu extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

    }

    /**
     * Método onClick de los botones. Dependiendo de cada botón, envía un String para saber qué boton se ha pulsado.
     * Así, siguiente activity mostrará lo necesario para esa actividad que ha pulsado.
     * @param view
     */
    public void onClick (View view){
        Intent intent = new Intent(getApplicationContext(), EjerciciosActivity.class);
        switch(view.getId()){
            case R.id.botEspalda:
                intent.putExtra("tipo","espalda");
                startActivity(intent);
                break;
            case R.id.botHombro:
                intent.putExtra("tipo","hombro");
                startActivity(intent);
                break;
            case R.id.botPecho:
                intent.putExtra("tipo","pecho");
                startActivity(intent);
                break;
            case R.id.botBiceps:
                intent.putExtra("tipo","biceps");
                startActivity(intent);
                break;
            case  R.id.botTriceps:
                intent.putExtra("tipo","triceps");
                startActivity(intent);
                break;
            case R.id.botPiernas:
                intent.putExtra("tipo","piernas");
                startActivity(intent);
                break;
            case R.id.botGemelos:
                intent.putExtra("tipo","gemelos");
                startActivity(intent);
                break;
            case R.id.botTrapecio:
                intent.putExtra("tipo","trapecio");
                startActivity(intent);
                break;
            case R.id.botAbdominal:
                intent.putExtra("tipo","abdominal");
                startActivity(intent);
                break;
            case R.id.botCardio:
                /**
                 * El boton Cardio, al ser una activity única, solo se inicializa esta.
                 */
                Intent intentcardio = new Intent(getApplicationContext(), Cardio.class);
                startActivity(intentcardio);
                break;
        }
    }
}
