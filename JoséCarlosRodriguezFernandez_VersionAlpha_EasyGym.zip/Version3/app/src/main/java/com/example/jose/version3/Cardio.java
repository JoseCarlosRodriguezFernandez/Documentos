package com.example.jose.version3;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Cardio extends AppCompatActivity {

    /**
     * Parametros:
     *
     * imagen: se refiere a la imagen que va a salir en la activity.
     * minutos: hace referencia a los minutos del Asyntask.
     * segundos: hace referencia a los segundos del Asyntask.
     * crono: Referencia la texto que usará el Asyntask.
     * time: Referencia al tiempo que el Asyntask va a estar ejecutandose.
     */
    static ImageView imagen;
    static int minutos = 0;
    static int segundos = 0;
    static TextView crono;
    static EditText tiempo;
    static int time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardio);
        ArrayAdapter<CharSequence> adapter;

        //Les indicamos a las variables que Views van a utilizar:
        tiempo = (EditText) findViewById(R.id.tiempocardio);
        TextView enunciado = (TextView) findViewById(R.id.enunciado1);
        Button cronometro = (Button) findViewById(R.id.crono1);
        Spinner spinner = (Spinner) findViewById(R.id.cardiospinner);
        crono = (TextView) findViewById(R.id.minutosview);

        //Creamos un adaptar, al que le pasamos por parametros un Array con los nombres que utilizará y un estilo:
        adapter = ArrayAdapter.createFromResource(this, R.array.ejescardio, R.layout.spinner_item_spinner);
        spinner.setAdapter(adapter);

        //Inicializamos las variables:
        enunciado.setText("Inserte minutos");
        imagen = findViewById(R.id.imagejerc);
        crono.setText(minutos + " minutos " + segundos + " segundos");

        //Creamos el metodo del Spinner que nos permite modificar las vistas dependiendo de la elección:
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String item = parent.getItemAtPosition(position).toString();
                //Depende de cual elijamos, cambiará una imagen u otra, y el tiempo del Asyntask cambiará a -1 para forzar su parado.
                switch (item) {
                    case "Cinta":
                        imagen.setImageResource(R.drawable.correr);
                        time = -1;
                        break;
                    case "Bicicleta":
                        imagen.setImageResource(R.drawable.bicicleta);
                        time = -1;
                        break;
                    case "Eliptica":
                        imagen.setImageResource(R.drawable.eliptica);
                        time = -1;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    //Funcion que provoca un segundo de parada en el cronometro
    private void tiempoespera(){
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {}
    }

    //Asyntask que permite el funcionamiento del cronometro:
    private class Cronometro extends AsyncTask<Void, Integer, Boolean>{
        @Override
        protected Boolean doInBackground(Void... voids) {
            //Esto es lo que se realiza en Background de la ejecución:
            Boolean ejecucion = true;
            time = Integer.parseInt(tiempo.getText().toString());
            time = time*60;
            if (time <= 0){
                this.cancel(true);
                ejecucion = false;
            }

            for(int i=0; i<time; i++) {
                    tiempoespera();
                    publishProgress();

                if(isCancelled() == true){
                    ejecucion = false;
                    break;
                }
            }
            return ejecucion;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            //Se cambia el valor de las variables y del Texto del cronómetro:
            segundos = segundos + 1;
            if(segundos == 60){
                segundos = 0;
                minutos = minutos + 1;
            }
            crono.setText(minutos + " minutos " + segundos + " segundos");

        }


        @Override
        protected void onPreExecute() {
            //Se prepara el cronómetro para su uso:
            minutos = 0;
            segundos = 0;
            crono.setText(minutos + " minutos " + segundos + " segundos");
        }

        @Override
        protected void onPostExecute(Boolean result) {
            //Cuando se ejecuta, te envia un mensaje de éxito y se termina la ejecución del Asyntask
            if (result == true) {
                Toast finejercicio = Toast.makeText(getApplicationContext(), "SE ACABÓ, A DESCANSAR", Toast.LENGTH_SHORT);
                finejercicio.show();
            }
        }

        @Override
        protected void onCancelled() {
            //Lo que provoca la cancelación del Asyntask
            time = -1;
        }
    }

    //Dependiendo de si pulsamos el boton de inicio o pausa, iniciará el Aynstask o forzará su parado:
    public void onClick(View view) {
        Cronometro tiempoejercicio = new Cronometro();
        switch (view.getId()) {
            case R.id.crono1:
                //Botón de inicio
                tiempoejercicio.execute();
                break;
            case R.id.crono2:
                //Botón de parada
                tiempo.setText("0");
                tiempoejercicio.cancel(true);
                break;
        }
    }
}