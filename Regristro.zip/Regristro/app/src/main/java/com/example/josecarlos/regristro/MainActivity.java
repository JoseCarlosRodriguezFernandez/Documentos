package com.example.josecarlos.regristro;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void guardarDatos(View v) {
        EditText nombreIn = this.findViewById(R.id.nombreIN);
        EditText numeroIn = this.findViewById(R.id.numeroIN);

        basedatos bd = new basedatos(this);

        String nombre = nombreIn.getText().toString();
        int entero = Integer.parseInt(numeroIn.getText().toString());

        bd.guardar(nombre, entero);
        Intent intent = new Intent (getApplicationContext(), scroll.class);
        startActivity(intent);


    }
    public void mostrarDatos(View v){
        LinearLayout lista = this.findViewById(R.id.listamostrar);

        basedatos bd = new basedatos(this);

        ArrayList<String> result = new ArrayList<String>();

        result = bd.consultar();

        for(String s: result){
            TextView linea = new TextView(this);
            linea.setText(s);
            lista.addView(linea);
        }

    }

    public void deletetable(View v){
        LinearLayout lista = this.findViewById(R.id.listamostrar);
        //TextView linea = new TextView(this);

        //linea.setText("");
        lista.removeAllViews();

        basedatos bd = new basedatos(this);
        bd.borrartabla();

    }

    public void cambiar(View v){
        Intent intent = new Intent (getApplicationContext(), scroll.class);
        startActivity(intent);
    }


}




