package com.example.josecarlos.regristro;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class basedatos extends SQLiteOpenHelper {

    public basedatos(Context context){
        super(context, "registro", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE tabla (" + "_id INTEGER PRIMARY KEY AUTOINCREMENT, texto TEXT, entero INTEGER)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newerVersion){

    }

    public void guardar(String texto, int entero){
        SQLiteDatabase db = getReadableDatabase();
        db.execSQL("INSERT INTO tabla VALUES (null,"+"'"+texto+"', "+entero+")");
    }

    public ArrayList<String> consultar(){

        ArrayList<String> result = new ArrayList<String>();

        SQLiteDatabase db = getReadableDatabase();

        System.out.println("Ruta de la base de datos: " + db.getPath());

        Cursor cursor = db.rawQuery("SELECT * FROM tabla ", null);

        while(cursor.moveToNext()){
            result.add(cursor.getInt(0)+", "+cursor.getString(1)+cursor.getInt(2));
        }

        cursor.close();
        return result;
    }

    public void borrartabla(){

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                SQLiteDatabase db = getReadableDatabase();
                db.execSQL("DELETE FROM tabla");
            }
        });
        t.start();
    }

}
