package com.example.josecarlos.regristro;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class scroll extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scroll);
    }
}
