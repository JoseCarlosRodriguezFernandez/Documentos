package com.example.josecarlos.version10;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }






    public void comprobar (View v){

        String [][] basedatos = {{"Paco", "Paco@gmail.com", "Paco"},
                {"Pepe", "Pepe@gmail.com", "Pepe"},
                {"Maria", "Maria@gmail.com", "Maria"},
                {"Alba","Alba@gmail.com","Alba"}};


        EditText nombreIn = this.findViewById(R.id.textoNomb);
        EditText correoIn = this.findViewById(R.id.textoCorreo);
        EditText passIn = this.findViewById(R.id.textoPass);

        String nombrecomp = nombreIn.getText().toString();
        String correocomp = correoIn.getText().toString();
        String passcomp = passIn.getText().toString();

        boolean comprobarnombre = false;
        boolean comprobarcorreo = false;
        boolean comprobarpass = false;

        for (int i = 0; i < basedatos.length; i++) {
            for (int j = 0; j < basedatos.length; j++) {
                if(j == 0){
                    if(nombrecomp.equals(basedatos[i][j]) == true){
                        comprobarnombre = true;
                    }
                    else{
                        comprobarnombre = false;
                    }
                }
                if(j == 1){
                    if(correocomp.equals(basedatos[i][j]) == true){
                        comprobarcorreo = true;
                    }
                    else{
                        comprobarcorreo = false;
                    }
                }
                if(j == 2){
                    if(passcomp.equals(basedatos[i][j]) == true){
                        comprobarpass = true;
                    }
                    else{
                        comprobarpass = false;
                    }
                }

            }
            if(comprobarnombre==true && comprobarcorreo == true && comprobarpass == true){
                Intent intent = new Intent(getApplicationContext(),Actividad2.class);
                startActivity(intent);
            }
        }

    }
}
