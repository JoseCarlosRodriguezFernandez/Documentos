package com.example.josecarlos.version10;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    static ArrayList<String> nombres = new ArrayList<>();
    static ArrayList<String> correos = new ArrayList<>();
    static ArrayList<String> passwords = new ArrayList<>();

    public void registro (View v){

        EditText nombreIn = this.findViewById(R.id.textoNomb);
        EditText correoIn = this.findViewById(R.id.textoCorreo);
        EditText passIn = this.findViewById(R.id.textoPass);

        String nombrecomp = nombreIn.getText().toString();
        String correocomp = correoIn.getText().toString();
        String passcomp = passIn.getText().toString();

        nombres.add(nombrecomp);
        correos.add(correocomp);
        passwords.add(passcomp);
    }



    public void comprobar (View v){

        EditText nombreIn = this.findViewById(R.id.textoNomb);
        EditText correoIn = this.findViewById(R.id.textoCorreo);
        EditText passIn = this.findViewById(R.id.textoPass);

        String nombrecomp = nombreIn.getText().toString();
        String correocomp = correoIn.getText().toString();
        String passcomp = passIn.getText().toString();

        boolean comprobarnombre = false;
        boolean comprobarcorreo = false;
        boolean comprobarpass = false;

        for (int i = 0; i < nombres.size(); i++) {
            if(nombrecomp.equals(nombres.get(i)) == true){
                comprobarnombre = true;
            }else{
                comprobarnombre = false;
            }
            if(correocomp.equals(correos.get(i))==true){
                comprobarcorreo = true;
            }else{
                comprobarcorreo = false;
            }
            if(passcomp.equals(passwords.get(i)) ==true){
                comprobarpass = true;
            }else{
                comprobarpass = false;
            }
            if(comprobarnombre==true && comprobarcorreo == true && comprobarpass == true){
                Intent intent = new Intent(getApplicationContext(),Actividad2.class);
                startActivity(intent);
            }
        }

    }


}
