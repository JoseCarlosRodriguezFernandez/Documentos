package com.example.josecarlos.version2;

import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class Espalda extends AppCompatActivity {

    static TextView explicacion;
    static ImageView imagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_espalda);

        ArrayAdapter<CharSequence> adapter;

        Spinner spinner = (Spinner) findViewById(R.id.espaldaspinner);

        adapter = ArrayAdapter.createFromResource(this, R.array.ejespaldas, R.layout.spinner_item_spinner);


        spinner.setAdapter(adapter);


        imagen = findViewById(R.id.imagejerc);
        explicacion = findViewById(R.id.textexplic);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();

                switch (item) {
                    case "Dominadas":
                        explicacion.setText(R.string.dominadas);
                        imagen.setImageResource(R.drawable.dominadas);
                        break;
                    case "Gironda":
                        explicacion.setText(R.string.gironda);
                        imagen.setImageResource(R.drawable.gironda);
                    break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });





        //explicacion.setText("Partiendo de la posición de reposo en la que los brazos se encuentran totalmente estirados, se eleva el cuerpo mediante la flexión de los brazos, hasta que la barbilla sobrepase a la barra de la cual se pende, sin elevar las piernas durante el proceso.");

    }
}
